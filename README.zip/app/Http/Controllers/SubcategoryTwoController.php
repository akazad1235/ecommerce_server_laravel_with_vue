<?php

namespace App\Http\Controllers;

use App\Models\SubcategoryTwo;
use Illuminate\Http\Request;

class SubcategoryTwoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\SubcategoryTwo  $subcategoryTwo
     * @return \Illuminate\Http\Response
     */
    public function show(SubcategoryTwo $subcategoryTwo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\SubcategoryTwo  $subcategoryTwo
     * @return \Illuminate\Http\Response
     */
    public function edit(SubcategoryTwo $subcategoryTwo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SubcategoryTwo  $subcategoryTwo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SubcategoryTwo $subcategoryTwo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\SubcategoryTwo  $subcategoryTwo
     * @return \Illuminate\Http\Response
     */
    public function destroy(SubcategoryTwo $subcategoryTwo)
    {
        //
    }
}
